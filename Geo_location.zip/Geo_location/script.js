
// const x = document.getElementById("demo");

async function getLocation() {
  if (navigator.geolocation) {
   await navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

let lati;
let lang
 async function showPosition(position) {
  lati = await position.coords.latitude;
  lang = await position.coords.longitude;
  sendData();
  // x.innerHTML = "Latitude: " + position.coords.latitude + 
  // "<br>Longitude: " + position.coords.longitude;
  // window.location.href = `https://www.latlong.net/c/?lat=${lati}&long=${lang}`;
  
}


function sendData(){
  let obj = [lati,lang]
  var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
       // Typical action to be performed when the document is ready:
      document.getElementById("demo").innerHTML = xhttp.responseText;
    }
};
xhttp.open("POST", "loc.php", true);
obj = JSON.stringify(obj);
xhttp.send(obj);
  console.log("Work This function send data");
}





getLocation();
showPosition();


